/**
 * 
 */
package com.cg.neel.igrs.query.query.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.neel.igrs.query.query.DocumentNotFoundAccessBean;

/**
 * @author Preeti
 *
 */
public interface DocumentNotFoundRepository extends JpaRepository<DocumentNotFoundAccessBean, Long> {

}
