/**
 * 
 */
package com.cg.neel.igrs.query.query.projection;

/**
 * @author Preeti
 *
 */
public interface QueryDropdownIdAndNameProjection {
	
	Long getQueryTypeId();
	String getQueryName();
	String getQueryNameHindi();

}
